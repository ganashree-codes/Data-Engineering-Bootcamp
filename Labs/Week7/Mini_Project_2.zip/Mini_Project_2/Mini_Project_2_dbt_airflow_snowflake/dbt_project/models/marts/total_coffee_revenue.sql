{{ config(materialized='table') }}

with coffee_revenue as (
                SELECT day,money,sales_id
                FROM {{ ref('stg_coffee_sales') }}),     

daily_summary as (
                SELECT
                    day,
                    COUNT(sales_id) as total_orders,
                    SUM(money) as total_revenue
                FROM coffee_revenue
                GROUP BY day
            )   

SELECT * FROM daily_summary