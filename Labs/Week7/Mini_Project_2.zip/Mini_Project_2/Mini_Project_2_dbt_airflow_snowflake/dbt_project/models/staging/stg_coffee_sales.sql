with source as(
    SELECT * 
    FROM {{ ref('coffee_sales') }}),

renamed as(
    SELECT
        MD5(CONCAT_WS('-', COALESCE(datetime::varchar, ''), COALESCE(card, 'cash'), COALESCE(coffee_name, ''), COALESCE(money::varchar, ''))) as sales_id,
        date::date as date,
        datetime::timestamp as datetime,
        cash_type::varchar as cash_type,
        card::varchar as card,
        money::decimal(10,2) as money,
        coffee_name::varchar as coffee_name,
        DATE(date::date) as day
    FROM source
    WHERE date is not null
)

SELECT * FROM renamed