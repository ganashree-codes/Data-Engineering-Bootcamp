# Databricks notebook source
#Load coffee_sales.csv into a DataFrame and find the total revenue.


from pyspark.sql.functions import sum

df = spark.read.csv("/Volumes/workspace/dataframe/dataframe/coffee_sales.csv", header=True, inferSchema=True)
total_revenue = df.select(sum("money")).collect()[0][0]
print(f"Total revenue: {total_revenue}")



# COMMAND ----------

#Find the number of transactions for each coffee_name using groupBy.

total_transactions = df.groupby("coffee_name").count().collect()

for row in total_transactions:
    print(f"{row['coffee_name']}: {row['count']}")

# COMMAND ----------


#Add a new column for month from the date column, and find total revenue per month.
from pyspark.sql.functions import month,col
df = df.withColumn("month", month(col("date"))) 
total_transactions_per_month = df.groupBy("month").agg(sum("money").alias("total_revenue")).orderBy("month").collect()

for row in total_transactions_per_month:
    print(f"Month {row['month']}: ${row['total_revenue']:.2f}")
      

# COMMAND ----------

query1 = """
SELECT coffee_name, SUM(money) AS revenue
FROM workspace.dataframe.coffee_sales
GROUP BY coffee_name
ORDER BY revenue DESC 
LIMIT 5
"""

# Run the query and display output
top_5_df = spark.sql(query1)
top_5_df.show()