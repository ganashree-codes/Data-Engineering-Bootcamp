--Write the SQL to create a stage and load spotify.csv into a Snowflake table.

CREATE OR REPLACE STAGE raw.spotify_data_stage;
LIST @raw.spotify_data_stage;
--CREATE OR REPLACE TABLE raw.spotify_data_stage_v2 LIKE raw.Spotify data;
CREATE OR REPLACE TABLE raw.spotify_data_stage_v2 (
    index_id INT,
    acousticness FLOAT,
    danceability FLOAT,
    duration_ms INT,
    energy FLOAT,
    instrumentalness FLOAT,
    key INT,
    liveness FLOAT,
    loudness FLOAT,
    mode INT,
    speechiness FLOAT,
    tempo FLOAT,
    time_signature INT,
    valence FLOAT,
    target INT,
    song_title VARCHAR(500),
    artist VARCHAR(500)
);
COPY INTO raw.spotify_data_stage_v2
  FROM @raw.spotify_data_stage
  FILE_FORMAT = (TYPE = CSV SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '"')
  ON_ERROR = 'CONTINUE';
--SELECT * FROM TABLE(VALIDATE(raw.spotify_data_stage_v2, JOB_ID => '_last'));
SELECT * FROM spotify_data_stage_v2

------------------------------------------------------------------------------------------------------------------------------------
--Write a query to find the top 3 songs by Drake.

SELECT song_title,artist,danceability,energy
FROM spotify_data_stage_v2
WHERE artist = 'Drake'
ORDER BY danceability DESC
LIMIT 3



