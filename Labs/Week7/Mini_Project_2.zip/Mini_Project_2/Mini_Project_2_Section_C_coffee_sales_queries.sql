---Write the SQL to create a stage and load coffee_sales.csv into a Snowflake table.



-- create an internal stage
CREATE OR REPLACE STAGE raw.coffee_sales_stage;
 
-- upload the file to the stage (run from SnowSQL CLI, or re-use the UI's
-- 'Load Data' wizard and point it at this stage instead of a table)
-- PUT file:///local/path/orders.csv @raw.orders_stage;
 
-- inspect what's in the stage
LIST @raw.coffee_sales_stage;
 --DROP TABLE IF EXISTS raw.coffee_sales_stage_v2;
-- load it into a second table so you can compare
-- 1. Create table with the correct coffee_sales schema
--CREATE OR REPLACE TABLE raw.coffee_sales_stage_v2 LIKE raw.coffee_sales;

CREATE OR REPLACE TABLE raw.coffee_sales_stage_v2 (
    date DATE,
    datetime TIMESTAMP,
    cash_type VARCHAR(50),
    card VARCHAR(100),
    money DECIMAL(10, 2),
    coffee_name VARCHAR(100)
);
-- 2. Copy the data from stage
COPY INTO raw.coffee_sales_stage_v2
  FROM @raw.coffee_sales_stage
  FILE_FORMAT = (TYPE = CSV SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '"')
  ON_ERROR = 'CONTINUE';
 
-- see which rows (if any) failed to load
--SELECT * FROM TABLE(VALIDATE(raw.coffee_sales_stage_v2, JOB_ID => '_last'));


SELECT * FROM COFFEE_SALES_STAGE_V2

-------------------------------------------------------------------------------------------------------------------------------------
---Write a query to find the top 3 coffee types by revenue.

SELECT SUM(money) AS revenue, coffee_name
FROM COFFEE_SALES_STAGE_V2
GROUP BY coffee_name
ORDER BY revenue DESC
LIMIT 3