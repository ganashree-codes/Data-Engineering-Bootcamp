with orders as (
    select * from {{ ref('stg_orders') }}
),
 
products as (
    select * from {{ ref('stg_products') }}
),
 
joined as (
    select
        p.product_id,
        count(o.order_id) as order_count,
        coalesce(sum(o.revenue), 0) as total_revenue
    from orders o
    left join products p on o.product_id = p.product_id
    group by p.product_id
)
 
select * from joined
