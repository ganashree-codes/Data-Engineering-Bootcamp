
{{ config(materialized='table') }}

with source as (
    select * from {{ ref('raw_products') }}
),
 
renamed as (
    select
        product_id,
        product_name,
        category,
        supplier_id,
        cost_price::decimal(10,2) as product_cost_price,
        selling_price::decimal(10,2) as product_selling_price
    from source
    where product_id is not null
)
 
select * from renamed
