with source as (
    select * from {{ ref('raw_orders') }}
),
 
renamed as (
    select
        order_id,
        customer_id,
        quantity,
        product_id,
        order_date::date as order_date,
        payment_status,
        unit_price::decimal(10,2) as order_amount,
        quantity * order_amount as revenue
    from source
    where order_id is not null
)
 
select * from renamed
