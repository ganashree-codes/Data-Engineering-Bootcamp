
-- test file to fail if amount is negative
SELECT *
FROM {{ ref('stg_orders') }}
WHERE order_amount < 0